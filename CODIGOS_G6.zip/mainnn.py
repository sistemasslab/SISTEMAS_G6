import sys
import pymysql
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import (
    QApplication, QMainWindow,
    QMessageBox, QTableWidgetItem
)
from PyQt5.uic import loadUi

# =========================
# CONFIGURACIÓN BD
# =========================

DB_CONFIG = {
    "host": "localhost",          
    "user": "root",               
    "password": "3939",           
    "database": "BBDD_Freechans",
    "port": 3306
}


def crear_conexion(host, user, password):
    return pymysql.connect(
        host=host,
        user=user,
        password=password,
        database=DB_CONFIG["database"],
        port=DB_CONFIG["port"],
        cursorclass=pymysql.cursors.Cursor
    )


# =========================
# VENTANA DE LOGIN
# =========================

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("ui_login.ui", self)

        # Conectar el botón real del .ui
        self.boton_validar_usuario.clicked.connect(self.conectar_bd)

        # Mensaje inicial en el textBrowser (si existe)
        if hasattr(self, "textBrowser"):
            self.textBrowser.append(
                "Ingrese host, usuario y contraseña, luego presione 'Validar usuario'."
            )

        self.connection = None

    def conectar_bd(self):
        """
        Lee los datos del formulario y abre la conexión a la base de datos.
        Si la conexión es exitosa, abre la ventana principal del sistema.
        """
        host_text = self.ingreso_localhost.text().strip()
        user = self.ingreso_usuario.text().strip()
        password = self.ingreso_contrasena.text().strip()

        # Si no se ingresó host, usamos el de la configuración (localhost)
        if host_text == "" or host_text.lower() == "host":
            host = DB_CONFIG["host"]
        else:
            host = host_text

        # Validación básica
        if user == "":
            QMessageBox.warning(self, "Datos incompletos", "Debe ingresar un usuario.")
            return

        try:
            # Creamos la conexión
            self.connection = crear_conexion(host, user, password)

            msg_ok = f"Conexión exitosa a la base de datos '{DB_CONFIG['database']}' en '{host}'."
            QMessageBox.information(self, "Éxito", msg_ok)

            if hasattr(self, "textBrowser"):
                self.textBrowser.append(msg_ok)

            # Abrir ventana principal del sistema
            self.menu_window = MenuWindow(self.connection)
            self.menu_window.show()
            self.hide()

        except pymysql.MySQLError as e:
            msg_error = f"Error de conexión: {e}"
            QMessageBox.critical(self, "Error de conexión", msg_error)
            if hasattr(self, "textBrowser"):
                self.textBrowser.append(msg_error)

    def closeEvent(self, event):
        """
        Cierra la conexión cuando se cierra la ventana de login.
        """
        try:
            if self.connection is not None:
                self.connection.close()
        except:
            pass
        event.accept()


# =========================
# VENTANA PRINCIPAL (SISTEMA)
# =========================

class MenuWindow(QMainWindow):
    def __init__(self, connection):
        super().__init__()
        loadUi("ui_main.ui", self)
        self.connection = connection

        # Cargar opciones en combo si está vacío
        if self.lista_query.count() == 0:
            self.lista_query.addItems([
                "Productos",
                "Stock",
                "Alertas de stock",
                "Categorías",
                "Proveedores",
                "Ventas",
                "Detalle ventas",
                "Conteos inventario",
                "Detalle conteos inventario"
            ])

        # Botones
        self.visualizar_boton.clicked.connect(self.visualizar_info)

        # botón para eliminar productos
        if hasattr(self, "btn_eliminar"):
            self.btn_eliminar.clicked.connect(self.eliminar_registro)

        # Botón para insertar categoría (panel derecho)
        if hasattr(self, "ingresar_datos"):
            self.ingresar_datos.clicked.connect(self.insertar_categoria)

        # Mensajes iniciales
        self.textBrowser.append(
            "Seleccione qué desea visualizar en la lista y presione 'Visualizar'."
        )

        # labels de consulta/registro:
        if hasattr(self, "lbl_query_actual"):
            self.lbl_query_actual.setText("Consulta actual: -")
        if hasattr(self, "lbl_total_registros"):
            self.lbl_total_registros.setText("Registros: 0")

        # Consulta actual (para controlar eliminar / recarga)
        self.consulta_actual = ""

    # ---------- UTILIDADES GENERALES ----------

    def ejecutar_consulta(self, query, params=None):
        """
        Ejecuta un SELECT y devuelve (filas, nombres_columnas).
        """
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(query, params or ())
                filas = cursor.fetchall()
                nombres_columnas = [col[0] for col in cursor.description]
            return filas, nombres_columnas
        except Exception as e:
            QMessageBox.critical(self, "Error SQL", str(e))
            return [], []

    def poblar_tabla(self, filas, columnas, nombre_consulta=""):
        """
        Llena tabla_query y actualiza el total de registros.
        """
        # Guardamos el nombre de la consulta actual
        self.consulta_actual = nombre_consulta

        self.tabla_query.clear()
        self.tabla_query.setRowCount(len(filas))
        self.tabla_query.setColumnCount(len(columnas))
        self.tabla_query.setHorizontalHeaderLabels(columnas)

        for i, fila in enumerate(filas):
            for j, valor in enumerate(fila):
                item = QTableWidgetItem(str(valor))
                self.tabla_query.setItem(i, j, item)

        self.tabla_query.resizeColumnsToContents()

        # Actualizar labels si existen
        if hasattr(self, "lbl_total_registros"):
            self.lbl_total_registros.setText(f"Registros: {len(filas)}")

        if hasattr(self, "lbl_query_actual") and nombre_consulta:
            self.lbl_query_actual.setText(f"Consulta actual: {nombre_consulta}")

    # ---------- LÓGICA DEL BOTÓN VISUALIZAR ----------

    def visualizar_info(self):
        """
        Según lo seleccionado en lista_query, ejecuta la consulta correspondiente.
        """
        opcion = self.lista_query.currentText()

        if opcion == "Productos":
            self.mostrar_productos()
        elif opcion == "Stock":
            self.mostrar_stock()
        elif opcion == "Alertas de stock":
            self.mostrar_alertas()
        elif opcion == "Categorías":
            self.mostrar_categorias()
        elif opcion == "Proveedores":
            self.mostrar_proveedores()
        elif opcion == "Ventas":
            self.mostrar_ventas()
        elif opcion == "Detalle ventas":
            self.mostrar_detalle_ventas()
        elif opcion == "Conteos inventario":
            self.mostrar_conteos()
        elif opcion == "Detalle conteos inventario":
            self.mostrar_detalle_conteos()
        else:
            QMessageBox.information(
                self, "Opción no válida",
                "Seleccione una opción válida en la lista."
            )

    # ---------- CONSULTAS PRINCIPALES ----------

    def mostrar_productos(self):
        query = """
            SELECT p.id_producto,
                   p.nombre,
                   c.nombre AS categoria,
                   t.nombre AS talla,
                   p.precio_venta,
                   p.stock_minimo,
                   p.estado_vigente
            FROM producto p
            JOIN categoria c ON c.id_categoria = p.id_categoria
            JOIN talla t     ON t.id_talla     = p.id_talla
            ORDER BY p.id_producto;
        """
        filas, columnas = self.ejecutar_consulta(query)
        self.poblar_tabla(filas, columnas, "Productos")
        self.textBrowser.append("Mostrando listado de productos.")

    def mostrar_stock(self):
        query = """
            SELECT id_producto,
                   nombre,
                   entradas,
                   salidas,
                   stock
            FROM v_stock
            ORDER BY id_producto;
        """
        filas, columnas = self.ejecutar_consulta(query)
        self.poblar_tabla(filas, columnas, "Stock")
        self.textBrowser.append("Mostrando stock (vista v_stock).")

    def mostrar_alertas(self):
        query = """
            SELECT id_producto,
                   nombre,
                   stock,
                   stock_minimo
            FROM v_alerta_repo
            ORDER BY id_producto;
        """
        filas, columnas = self.ejecutar_consulta(query)
        if not filas:
            QMessageBox.information(self, "Alertas", "No hay productos en nivel crítico de stock.")
            self.textBrowser.append("No hay alertas de stock.")
        else:
            self.textBrowser.append("Mostrando alertas de stock (v_alerta_repo).")

        self.poblar_tabla(filas, columnas, "Alertas de stock")

    def mostrar_categorias(self):
        query = """
            SELECT id_categoria,
                   nombre,
                   descripcion,
                   estado_vigente
            FROM categoria
            ORDER BY id_categoria;
        """
        filas, columnas = self.ejecutar_consulta(query)
        self.poblar_tabla(filas, columnas, "Categorías")
        self.textBrowser.append("Mostrando listado de categorías.")

    def mostrar_proveedores(self):
        query = """
            SELECT id_proveedor,
                   nombre,
                   rut,
                   telefono,
                   email,
                   direccion
            FROM proveedor
            ORDER BY id_proveedor;
        """
        filas, columnas = self.ejecutar_consulta(query)
        self.poblar_tabla(filas, columnas, "Proveedores")
        self.textBrowser.append("Mostrando listado de proveedores.")

    def mostrar_ventas(self):
        query = """
            SELECT id_venta,
                   fecha_hora,
                   medio_pago,
                   monto_total,
                   terminal_pago,
                   nro_transaccion
            FROM venta
            ORDER BY id_venta;
        """
        filas, columnas = self.ejecutar_consulta(query)
        self.poblar_tabla(filas, columnas, "Ventas")
        self.textBrowser.append("Mostrando listado de ventas.")

    def mostrar_detalle_ventas(self):
        query = """
            SELECT dv.id_venta,
                   v.fecha_hora,
                   dv.id_producto,
                   p.nombre AS producto,
                   dv.cantidad,
                   dv.precio_unitario,
                   dv.subtotal
            FROM detalle_venta dv
            JOIN venta v     ON v.id_venta     = dv.id_venta
            JOIN producto p  ON p.id_producto  = dv.id_producto
            ORDER BY dv.id_venta, dv.id_producto;
        """
        filas, columnas = self.ejecutar_consulta(query)
        self.poblar_tabla(filas, columnas, "Detalle ventas")
        self.textBrowser.append("Mostrando detalle de ventas.")

    def mostrar_conteos(self):
        query = """
            SELECT id_conteo,
                   fecha_conteo
            FROM conteo_inventario
            ORDER BY fecha_conteo, id_conteo;
        """
        filas, columnas = self.ejecutar_consulta(query)
        self.poblar_tabla(filas, columnas, "Conteos inventario")
        self.textBrowser.append("Mostrando conteos de inventario.")

    def mostrar_detalle_conteos(self):
        query = """
            SELECT dci.id_conteo,
                   ci.fecha_conteo,
                   dci.id_producto,
                   p.nombre AS producto,
                   dci.stock_sistema,
                   dci.stock_fisico,
                   dci.diferencia
            FROM detalle_conteo_inventario dci
            JOIN conteo_inventario ci ON ci.id_conteo   = dci.id_conteo
            JOIN producto p           ON p.id_producto  = dci.id_producto
            ORDER BY dci.id_conteo, dci.id_producto;
        """
        filas, columnas = self.ejecutar_consulta(query)
        self.poblar_tabla(filas, columnas, "Detalle conteos inventario")
        self.textBrowser.append("Mostrando detalle de conteos de inventario.")

    # ---------- INSERTAR CATEGORÍAS (panel derecho) ----------

    def insertar_categoria(self):
        """
        Inserta una nueva categoría en la tabla `categoria` usando los campos de la derecha.
        """
        id_categoria = self.id_categoria_ingresar.text().strip()
        nombre = self.nombre_ingresar.text().strip()
        descripcion = self.descripcion_ingresar.text().strip()
        estado = self.estado_vigente_ingresar.text().strip()

        # Validaciones básicas
        if id_categoria == "" or nombre == "" or estado == "":
            QMessageBox.warning(
                self,
                "Datos incompletos",
                "Debe ingresar al menos: ID categoría, Nombre y Estado vigente."
            )
            return

        # Confirmación
        resp = QMessageBox.question(
            self,
            "Confirmar inserción",
            f"¿Desea registrar la categoría '{id_categoria}'?",
            QMessageBox.Yes | QMessageBox.No
        )
        if resp != QMessageBox.Yes:
            return

        # Intentar insertar en la BD
        try:
            with self.connection.cursor() as cursor:
                sql = """
                    INSERT INTO categoria (id_categoria, nombre, descripcion, estado_vigente)
                    VALUES (%s, %s, %s, %s);
                """
                cursor.execute(sql, (id_categoria, nombre, descripcion, estado))
            self.connection.commit()

            QMessageBox.information(
                self,
                "Categoría registrada",
                f"La categoría '{id_categoria}' fue registrada correctamente."
            )
            self.textBrowser.append(f"Se insertó la categoría {id_categoria}.")

            # Limpiar campos
            self.id_categoria_ingresar.clear()
            self.nombre_ingresar.clear()
            self.descripcion_ingresar.clear()
            self.estado_vigente_ingresar.clear()

            # Si estamos viendo Categorías, recargar la tabla
            if self.consulta_actual == "Categorías":
                self.mostrar_categorias()

        except pymysql.err.IntegrityError as e:
            # Error típico: PK duplicada
            self.connection.rollback()
            QMessageBox.critical(
                self,
                "Error de integridad",
                f"No se pudo insertar la categoría. Verifique que el ID '{id_categoria}' no exista.\n\n{e}"
            )
        except Exception as e:
            self.connection.rollback()
            QMessageBox.critical(
                self,
                "Error al insertar",
                f"Ocurrió un error al insertar la categoría:\n{e}"
            )

    # ---------- ELIMINAR PRODUCTO (desde vista Productos) ----------

    def eliminar_registro(self):
        """
        Elimina un producto según la fila seleccionada en la tabla.
        solo permite eliminar cuando la consulta es 'Productos'.
        """
        # Verificar que la consulta actual sea Productos
        if self.consulta_actual != "Productos":
            QMessageBox.information(
                self,
                "Acción no permitida",
                "Solo se pueden eliminar registros cuando se está visualizando 'Productos'."
            )
            return

        # Fila seleccionada
        fila = self.tabla_query.currentRow()
        if fila < 0:
            QMessageBox.warning(
                self,
                "Sin selección",
                "Debe seleccionar una fila en la tabla."
            )
            return

        # Asumimos que la primera columna es id_producto
        item_id = self.tabla_query.item(fila, 0)
        if item_id is None:
            QMessageBox.warning(
                self,
                "Error",
                "No se pudo leer el id del producto seleccionado."
            )
            return

        try:
            id_producto = int(item_id.text())
        except ValueError:
            QMessageBox.warning(
                self,
                "Error",
                "El valor de id_producto no es válido."
            )
            return

        # Confirmación
        respuesta = QMessageBox.question(
            self,
            "Confirmar eliminación",
            f"¿Seguro que desea eliminar el producto con id {id_producto}?",
            QMessageBox.Yes | QMessageBox.No
        )

        if respuesta != QMessageBox.Yes:
            return  # Canceló

        # Ejecutar DELETE en la base de datos
        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    "DELETE FROM producto WHERE id_producto = %s",
                    (id_producto,)
                )
            self.connection.commit()

            QMessageBox.information(
                self,
                "Eliminado",
                f"Producto con id {id_producto} eliminado correctamente."
            )
            self.textBrowser.append(f"Se eliminó el producto id {id_producto}.")

            # Recargar listado de productos
            self.mostrar_productos()

        except Exception as e:
            self.connection.rollback()
            QMessageBox.critical(
                self,
                "Error al eliminar",
                f"Ocurrió un error al eliminar el producto:\n{e}"
            )

    def closeEvent(self, event):
        """
        Cierra la conexión al cerrar la ventana principal.
        """
        try:
            self.connection.close()
        except:
            pass
        event.accept()


# =========================
# MAIN
# =========================

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = MainWindow()
    ventana.show()
    sys.exit(app.exec_())
