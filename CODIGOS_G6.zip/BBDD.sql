DROP DATABASE IF EXISTS BBDD_Freechans; 
CREATE DATABASE IF NOT EXISTS BBDD_Freechans;
USE BBDD_Freechans;

-- =========================
-- TABLAS DE CATÁLOGO
-- =========================

CREATE TABLE categoria (
  id_categoria   VARCHAR(120) PRIMARY KEY,
  nombre         VARCHAR(120) NOT NULL,
  descripcion    VARCHAR(120),
  estado_vigente VARCHAR(120) NOT NULL
);

CREATE TABLE talla (
  id_talla       VARCHAR(120) PRIMARY KEY,
  nombre         VARCHAR(120) NOT NULL,
  descripcion    VARCHAR(120),
  estado_vigente VARCHAR(120) NOT NULL
);

-- =========================
-- PRODUCTOS
-- =========================

CREATE TABLE producto (
  id_producto    INT PRIMARY KEY,
  nombre         VARCHAR(120) NOT NULL,
  descripcion    VARCHAR(120),
  id_categoria   VARCHAR(120) NOT NULL,
  id_talla       VARCHAR(120) NOT NULL,
  costo_unitario DECIMAL(10,2),       -- referencia
  precio_venta   DECIMAL(10,2),       -- referencia
  stock_actual   INT,
  stock_minimo   INT NOT NULL,
  fecha_ingreso  DATE,
  estado_vigente VARCHAR(120) NOT NULL,
  FOREIGN KEY (id_categoria) REFERENCES categoria (id_categoria),
  FOREIGN KEY (id_talla)     REFERENCES talla (id_talla)
);

ALTER TABLE producto
  MODIFY id_producto INT NOT NULL AUTO_INCREMENT;

-- =========================
-- PROVEEDORES
-- =========================

CREATE TABLE proveedor (
  id_proveedor INT PRIMARY KEY,
  nombre       VARCHAR(120) NOT NULL,
  rut          VARCHAR(12) NOT NULL,
  telefono     VARCHAR(15),
  email        VARCHAR(120),
  direccion    VARCHAR(120)
);

ALTER TABLE proveedor
  MODIFY id_proveedor INT NOT NULL AUTO_INCREMENT;

-- =========================
-- COMPRAS (LOTES)
-- =========================

CREATE TABLE lote_compra (
  id_lote          INT PRIMARY KEY,
  id_proveedor     INT NOT NULL,
  fecha_recepcion  DATE NOT NULL,
  tipo_documento   VARCHAR(120) NOT NULL,
  numero_documento VARCHAR(120) NOT NULL,
  monto_total      DECIMAL(10,2),
  FOREIGN KEY (id_proveedor) REFERENCES proveedor (id_proveedor)
);

ALTER TABLE lote_compra
  MODIFY id_lote INT NOT NULL AUTO_INCREMENT;

CREATE TABLE detalle_lote (
  id_lote        INT,
  id_producto    INT,
  cantidad       INT NOT NULL,
  costo_unitario DECIMAL(10,2) NOT NULL,
  subtotal       DECIMAL(10,2),
  CONSTRAINT id_detalle_lote PRIMARY KEY (id_lote, id_producto),
  CONSTRAINT id_lote        FOREIGN KEY (id_lote)     REFERENCES lote_compra (id_lote),
  CONSTRAINT id_producto_lote FOREIGN KEY (id_producto) REFERENCES producto (id_producto)
);

-- =========================
-- VENTAS
-- =========================

CREATE TABLE venta (
  id_venta       INT PRIMARY KEY,
  fecha_hora     DATE NOT NULL,
  medio_pago     VARCHAR(120) NOT NULL,
  monto_total    DECIMAL(10,2),
  terminal_pago  VARCHAR(120),
  nro_transaccion VARCHAR(120)
);

ALTER TABLE venta
  MODIFY id_venta INT NOT NULL AUTO_INCREMENT;

CREATE TABLE detalle_venta (
  id_venta       INT,
  id_producto    INT,
  cantidad       INT NOT NULL,
  precio_unitario DECIMAL(10,2) NOT NULL,
  subtotal       DECIMAL(10,2),
  CONSTRAINT id_detalle_venta  PRIMARY KEY (id_venta, id_producto),
  CONSTRAINT id_venta          FOREIGN KEY (id_venta)    REFERENCES venta (id_venta),
  CONSTRAINT producto_id_venta FOREIGN KEY (id_producto) REFERENCES producto (id_producto)
);

-- =========================
-- CONTEO DE INVENTARIO
-- =========================

CREATE TABLE conteo_inventario (
  id_conteo     INT PRIMARY KEY,
  fecha_conteo  DATE NOT NULL
);

ALTER TABLE conteo_inventario
  MODIFY id_conteo INT NOT NULL AUTO_INCREMENT;

CREATE TABLE detalle_conteo_inventario (
  id_conteo      INT,
  id_producto    INT,
  stock_sistema  INT,
  stock_fisico   INT,
  diferencia     INT,
  CONSTRAINT id_detalle_conteo_inventario PRIMARY KEY (id_conteo, id_producto),
  CONSTRAINT conteo_id             FOREIGN KEY (id_conteo)   REFERENCES conteo_inventario (id_conteo),
  CONSTRAINT producto_id_inventario FOREIGN KEY (id_producto) REFERENCES producto (id_producto)
);

-- =========================
-- DATOS DE EJEMPLO
-- =========================

INSERT INTO categoria (id_categoria, nombre, descripcion, estado_vigente) VALUES
('CAT01', 'Poleras', 'Poleras casuales de mujer', 'ACTIVO'),
('CAT02', 'Polerones', 'Polerones y hoodies', 'ACTIVO'),
('CAT03', 'Pantalones', 'Jeans y pantalones de mujer', 'ACTIVO'),
('CAT04', 'Faldas', 'Faldas cortas y largas', 'ACTIVO'),
('CAT05', 'Vestidos', 'Vestidos casuales y formales', 'ACTIVO'),
('CAT06', 'Blusas', 'Blusas y camisas', 'ACTIVO'),
('CAT07', 'Chaquetas', 'Chaquetas de abrigo', 'ACTIVO'),
('CAT08', 'Shorts', 'Shorts de verano', 'ACTIVO'),
('CAT09', 'Accesorios', 'Cinturones, pañuelos', 'ACTIVO'),
('CAT10', 'Outlet', 'Prendas con descuento', 'ACTIVO');

INSERT INTO talla (id_talla, nombre, descripcion, estado_vigente) VALUES
('XS', 'XS', 'Talla extra pequeña', 'ACTIVO'),
('S',  'S',  'Talla pequeña', 'ACTIVO'),
('M',  'M',  'Talla mediana', 'ACTIVO'),
('L',  'L',  'Talla grande', 'ACTIVO'),
('XL', 'XL', 'Talla extra grande', 'ACTIVO'),
('U',  'Única', 'Talla única', 'ACTIVO'),
('36', '36', 'Talla pantalón 36', 'ACTIVO'),
('38', '38', 'Talla pantalón 38', 'ACTIVO'),
('40', '40', 'Talla pantalón 40', 'ACTIVO'),
('42', '42', 'Talla pantalón 42', 'ACTIVO');

INSERT INTO producto
(id_producto, nombre, descripcion, id_categoria, id_talla,
 costo_unitario, precio_venta, stock_actual, stock_minimo,
 fecha_ingreso, estado_vigente)
VALUES
(1, 'Polera básica blanca', 'Polera manga corta algodón', 'CAT01', 'M', 2000,  6000, 15, 3, '2025-10-01', 'ACTIVO'),
(2, 'Polera estampada negra', 'Polera con diseño frontal', 'CAT01', 'L', 2500,  7000, 10, 3, '2025-10-02', 'ACTIVO'),
(3, 'Polerón oversized gris', 'Polerón con capucha',       'CAT02', 'M', 3500, 12000,  8, 2, '2025-10-03', 'ACTIVO'),
(4, 'Jeans skinny azul',      'Jeans tiro alto',           'CAT03', '38',4000, 14000, 12, 3, '2025-10-04', 'ACTIVO'),
(5, 'Falda plisada negra',    'Falda midi plisada',        'CAT04', 'M', 3000, 11000,  6, 2, '2025-10-05', 'ACTIVO'),
(6, 'Vestido floral',         'Vestido corto floreado',    'CAT05', 'S', 3200, 13000,  7, 2, '2025-10-06', 'ACTIVO'),
(7, 'Blusa satinada beige',   'Blusa manga larga',         'CAT06', 'M', 2800, 11500,  9, 2, '2025-10-07', 'ACTIVO'),
(8, 'Chaqueta de mezclilla',  'Chaqueta jean clásica',     'CAT07', 'L', 4500, 16000,  5, 1, '2025-10-08', 'ACTIVO'),
(9, 'Short de mezclilla',     'Short tiro alto',           'CAT08', '36',2500,  9000, 11, 3, '2025-10-09', 'ACTIVO'),
(10,'Cinturón negro',         'Cinturón cuero sintético',  'CAT09', 'U', 1500,  5000, 20, 5, '2025-10-10', 'ACTIVO');

INSERT INTO proveedor
(id_proveedor, nombre, rut, telefono, email, direccion)
VALUES
(1, 'Importadora Andes',   '76.111.111-1', '+56911111111', 'contacto@andes.cl',         'Santiago, Chile'),
(2, 'Ropa Miami Chile',    '77.222.222-2', '+56922222222', 'ventas@miamiropa.cl',       'Viña del Mar, Chile'),
(3, 'Mayorista Fashion',   '78.333.333-3', '+56933333333', 'info@fashionmayorista.cl',  'Concepción, Chile'),
(4, 'Outlet USA Ltda',     '79.444.444-4', '+56944444444', 'contacto@outletusa.cl',     'Valparaíso, Chile'),
(5, 'Vintage Import',      '80.555.555-5', '+56955555555', 'ventas@vintageimport.cl',   'Santiago, Chile'),
(6, 'Textiles Pacífico',   '81.666.666-6', '+56966666666', 'ventas@pacifico.cl',        'La Serena, Chile'),
(7, 'Moda Urbana',         '82.777.777-7', '+56977777777', 'contacto@modaurbana.cl',    'Santiago, Chile'),
(8, 'Prendas del Sur',     '83.888.888-8', '+56988888888', 'ventas@prendassur.cl',      'Temuco, Chile'),
(9, 'Mayorista Centro',    '84.999.999-9', '+56999999999', 'info@mayoristacentro.cl',   'Rancagua, Chile'),
(10,'Ropa América',        '85.123.456-7', '+56912345678', 'contacto@ropaamerica.cl',   'Santiago, Chile');

INSERT INTO lote_compra
(id_lote, id_proveedor, fecha_recepcion, tipo_documento,
 numero_documento, monto_total)
VALUES
(1, 1, '2025-09-20', 'Factura', 'F-1001', 200000),
(2, 2, '2025-09-25', 'Factura', 'F-1002', 180000),
(3, 3, '2025-10-01', 'Boleta',  'B-2001', 150000),
(4, 4, '2025-10-05', 'Factura', 'F-1003', 220000),
(5, 5, '2025-10-10', 'Boleta',  'B-2002', 130000),
(6, 6, '2025-10-12', 'Factura', 'F-1004', 190000),
(7, 7, '2025-10-15', 'Boleta',  'B-2003', 160000),
(8, 8, '2025-10-18', 'Factura', 'F-1005', 210000),
(9, 9, '2025-10-20', 'Boleta',  'B-2004', 140000),
(10,10,'2025-10-22', 'Factura', 'F-1006', 230000);

INSERT INTO detalle_lote
(id_lote, id_producto, cantidad, costo_unitario, subtotal)
VALUES
(1, 1, 20, 2000, 40000),
(1, 2, 15, 2500, 37500),
(2, 3, 10, 3500, 35000),
(2, 4, 15, 4000, 60000),
(3, 5, 10, 3000, 30000),
(3, 6, 10, 3200, 32000),
(4, 7, 15, 2800, 42000),
(4, 8,  8, 4500, 36000),
(5, 9, 20, 2500, 50000),
(5,10,25, 1500, 37500);

INSERT INTO venta
(id_venta, fecha_hora, medio_pago, monto_total, terminal_pago, nro_transaccion)
VALUES
(1, '2025-11-01', 'Efectivo', 26000,   'N/A',       '0'),
(2, '2025-11-01', 'Tarjeta',  14000,   'Getnet',    '1001'),
(3, '2025-11-02', 'Tarjeta',  19000,   'Getnet',    '1002'),
(4, '2025-11-02', 'Efectivo', 11000,   'N/A',       '0'),
(5, '2025-11-03', 'Tarjeta',  16000,   'Transbank', '2001'),
(6, '2025-11-03', 'Efectivo',  9000,   'N/A',       '0'),
(7, '2025-11-04', 'Tarjeta',  21000,   'Getnet',    '1003'),
(8, '2025-11-04', 'Efectivo', 13000,   'N/A',       '0'),
(9, '2025-11-05', 'Tarjeta',  18000,   'Transbank', '2002'),
(10,'2025-11-05', 'Efectivo', 12000,   'N/A',       '0');

INSERT INTO detalle_venta
(id_venta, id_producto, cantidad, precio_unitario, subtotal)
VALUES
(1, 1, 2,  6000, 12000),
(1,10, 2,  5000, 10000),
(2, 4, 1, 14000, 14000),
(3, 3, 1, 12000, 12000),
(3,10, 1,  5000,  5000),
(4, 5, 1, 11000, 11000),
(5, 8, 1, 16000, 16000),
(6, 9, 1,  9000,  9000),
(7, 6, 1, 13000, 13000),
(7,10, 1,  5000,  5000);

INSERT INTO conteo_inventario
(id_conteo, fecha_conteo)
VALUES
(1, '2025-11-01'),
(2, '2025-11-08'),
(3, '2025-11-15'),
(4, '2025-11-22'),
(5, '2025-11-29'),
(6, '2025-12-06'),
(7, '2025-12-13'),
(8, '2025-12-20'),
(9, '2025-12-27'),
(10,'2026-01-03');

INSERT INTO detalle_conteo_inventario
(id_conteo, id_producto, stock_sistema, stock_fisico, diferencia)
VALUES
(1, 1, 15, 15,  0),
(1, 2, 10,  9, -1),
(2, 3,  8,  8,  0),
(2, 4, 12, 11, -1),
(3, 5,  6,  6,  0),
(3, 6,  7,  6, -1),
(4, 7,  9,  9,  0),
(4, 8,  5,  4, -1),
(5, 9, 11, 10, -1),
(5,10,20, 19, -1);

-- =========================
-- VISTAS DE APOYO (STOCK Y ALERTAS)
-- =========================

CREATE OR REPLACE VIEW v_stock AS
SELECT  p.id_producto,
        p.nombre,
        COALESCE(SUM(dl.cantidad),0) AS entradas,
        COALESCE((
          SELECT SUM(dv.cantidad)
          FROM detalle_venta dv
          WHERE dv.id_producto = p.id_producto
        ),0) AS salidas,
        COALESCE(SUM(dl.cantidad),0) -
        COALESCE((
          SELECT SUM(dv.cantidad)
          FROM detalle_venta dv
          WHERE dv.id_producto = p.id_producto
        ),0) AS stock
FROM producto p
LEFT JOIN detalle_lote dl ON dl.id_producto = p.id_producto
GROUP BY p.id_producto, p.nombre;

CREATE OR REPLACE VIEW v_alerta_repo AS
SELECT p.id_producto,
       p.nombre,
       vs.stock,
       p.stock_minimo
FROM producto p
JOIN v_stock vs ON vs.id_producto = p.id_producto
WHERE vs.stock <= p.stock_minimo;
